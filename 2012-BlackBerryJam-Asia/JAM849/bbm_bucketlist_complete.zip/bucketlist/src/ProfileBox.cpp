/* Copyright (c) 2012 Research In Motion Limited.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#include <bb/cascades/Container>
#include <bb/cascades/LongPressHandler>

#include <bb/platform/bbm/ProfileBoxItem>
#include "ProfileBox.h"
#include "Global.h"

using namespace bb::cascades;

static const QString logPrefix("ProfileBox");

ProfileBox::ProfileBox()
{
	//Get an instance of bb::platform::bbm::ProfileBox
	m_profileBox = new bb::platform::bbm::ProfileBox(
			Global::instance()->getContext(), this);

	//Register the icons we plan to use in the ProfileBox items.
	registerIcons();
}

//The ProfileBox items use the same icons as the application menu.
//Images are located in the assets/images directory.
//finished.png, chickened.png and todo.png are used.
void ProfileBox::registerIcons()
{
	QString imageDir(QDir::currentPath() + "/app/native/assets/images/");
	registerIcon(imageDir + "finished.png", 1);
	registerIcon(imageDir + "chickened.png", 2);
	registerIcon(imageDir + "todo.png", 3);
}

//Register an icon with the BBBM SP.
void ProfileBox::registerIcon(const QString& path, int iconId)
{
	qDebug() << logPrefix << ": Registering icon id=" << iconId << ", path="
			<< path;

	// Read the icon from the file
	QImage image;
	QByteArray iconArray;
	QBuffer buffer(&iconArray);
	buffer.open(QIODevice::WriteOnly);
	if (not image.load(path))
	{
		qDebug() << logPrefix << ": Failed to load icon";
		return;
	}
	qDebug() << logPrefix << ": Icon loaded";
	image.save(&buffer, "PNG");

	// Create the icon object and register the icon
	const bool result = m_profileBox->requestRegisterIcon(iconId,
			bb::platform::bbm::ImageType::Png, iconArray);
	qDebug() << logPrefix << ": Icon registered; result=" << result;
}

//Creates a new item in the application's ProfileBox.
void ProfileBox::createItem(const QString& text, const QString& iconPath)
{
	qDebug() << logPrefix << ": Adding item";

	// Icon was selected. Determine its ID
	int iconId;
	if (iconPath == "images/finished.png")
	{
		iconId = 1;
	} else if (iconPath == "images/chickened.png")
	{
		iconId = 2;
	} else if (iconPath == "images/todo.png")
	{
		iconId = 3;
	} else
	{
		qDebug() << logPrefix
				<< ": Item could not be added because icon ID could not"
						" be determined; iconPath=" << iconPath;
		return;
	}

	// Add the ProfileBox item.
	const bool result = m_profileBox->requestAddItem(text, iconId,
			QString("cookie"));
	qDebug() << logPrefix << ": Added item with icon; result=" << result;
}
