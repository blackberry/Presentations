/* Copyright (c) 2012 Research In Motion Limited.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#include "bucketlistapp.h"
#include "bucketmodel.h"
#include "ProfileBox.h"
#include "ProfileMessage.h"

#include <bb/cascades/QmlDocument>
#include <bb/cascades/AbstractPane>

using namespace bb::cascades;

BucketListApp::BucketListApp()
{
  // The model for populating the bucket list is registered, so that it and all its
  // properties can be accessed directly from QML. This is done before creating the
  // QmlDocument below so that it is available when the corresponding QML component
  // is needed (see main.qml).
  qmlRegisterType<BucketModel>("com.bucketlist.bucketmodel", 1, 0, "BucketModel");

//TODO SOHM
  //Register ProfileBox so that it can be used within our QML documents.
  qmlRegisterType<ProfileBox>("com.bucketlist.profilebox", 1, 0, "ProfileBox");

  //TODO SOHM
  //Register ProfileMessage so that it can be used within our QML documents.
  qmlRegisterType<ProfileMessage>("com.bucketlist.profilemessage", 1, 0, "ProfileMessage");

//SOHM

  // Create a QMLDocument and load it, using build patterns.
  QmlDocument *qml = QmlDocument::create("asset:///main.qml");

  if (!qml->hasErrors()) {

    AbstractPane *appPage = qml->createRootObject<AbstractPane>();

    if (appPage) {
      // Set the main scene to the application Page.
      Application::instance()->setScene(appPage);
    }
  }
}
