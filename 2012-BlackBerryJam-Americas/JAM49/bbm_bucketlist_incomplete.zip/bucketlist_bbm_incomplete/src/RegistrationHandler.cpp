/* Copyright (c) 2012 Research In Motion Limited.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#include "RegistrationHandler.h"
#include <bb/platform/bbm/RegistrationState>
#include <bb/platform/bbm/Context>

#include <bb/cascades/QmlDocument>

#include "Global.h"
#include "bucketlistapp.h"

using namespace bb::cascades;

RegistrationHandler::RegistrationHandler()
{
	// Create the UI for the registration page and its components.
	QmlDocument* qmlContent = QmlDocument::create("asset:///registration.qml");
	if (qmlContent)
	{
		Control* content = qmlContent->createRootObject<Control>();
		this->setContent(content);
	}

	// Console Setup -- link BbmspBpsEventHandler to registrationCallback().
	m_statusText = this->findChild<TextArea*>("statusText");

	// Retrieve the button
	m_continueButton = this->findChild<Button*>("continueButton");

	// Connect the callback for the button.
	QObject::connect(m_continueButton, SIGNAL(clicked()), this,
			SLOT(continueToMainAppScreen()));

	// Attempt to register the application with the following UUID.
	//TODO:  Define your own UUID here.  You can generate one here: http://www.guidgenerator.com/
	//m_uuid = QString::fromUtf8("b540c0af-c71b-4f04-bdf3-a77463d29f7c"); //original

	this->appRegister();

}

void RegistrationHandler::appRegister()
{
	qDebug() << "entering appRegister -> " << m_uuid;
	qDebug() << "before new Context";
	m_context = new bb::platform::bbm::Context(QUuid(m_uuid));
	Global::instance()->setContext(m_context);

	//TODO: Connect the BBM SP registration signals to our application's slot.



	qDebug() << "after new Context and connect";
	m_context->requestRegisterApplication();
	qDebug() << "registered -> " << m_uuid;
}

void RegistrationHandler::checkRegistrationAccess()
{
	bb::platform::bbm::RegistrationState::Type status =
			bb::platform::bbm::RegistrationState::Unknown;
	if (Global::instance()->getContext())
	{
		status = Global::instance()->getContext()->registrationState();
	}
	registrationStatus(status);
}

void RegistrationHandler::registrationStatus(
		bb::platform::bbm::RegistrationState::Type state)
{
	qDebug() << "Registration Status received";

	switch (state)
	{

	case bb::platform::bbm::RegistrationState::Allowed:
		qDebug() << "RegistrationPage::registrationStatus Access allowed";

		//TODO:  Update the registration screen after access is allowed.
		//Place a success message in m_statusText and make m_continueButton visible.



		break;

	case bb::platform::bbm::RegistrationState::Unregistered:
		qDebug() << ("Unregistered");
		this->registrationFailed();
		break;

	case bb::platform::bbm::RegistrationState::Unknown:
		qDebug() << ("Access failed: unknown reason");
		this->registrationFailed();
		break;

	case bb::platform::bbm::RegistrationState::Pending:
		qDebug() << "RegistrationState::Pending";
		this->registrationFailed();
		break;

	case bb::platform::bbm::RegistrationState::BlockedByUser:
		qDebug() << ("Access failed: blocked by user");
		this->registrationFailed();
		break;

	case bb::platform::bbm::RegistrationState::BlockedByRIM:
		qDebug() << ("Access failed: blocked by RIM");
		this->registrationFailed();
		break;

	case bb::platform::bbm::RegistrationState::NoDataConnection:
		qDebug() << ("Access failed: no data coverage");
		this->registrationFailed();
		break;

	case bb::platform::bbm::RegistrationState::UnexpectedError:
		qDebug() << ("Access failed: unexpected error");
		this->registrationFailed();
		break;

	case bb::platform::bbm::RegistrationState::InvalidUuid:
		qDebug() << ("Access failed: invalid UUID");
		this->registrationFailed();
		break;

	case bb::platform::bbm::RegistrationState::TemporaryError:
		qDebug() << ("Access failed: temporary error");
		this->registrationFailed();
		break;

	case bb::platform::bbm::RegistrationState::CancelledByUser:
		qDebug() << ("Access cancelled by user");
		this->registrationFailed();
		break;

	case bb::platform::bbm::RegistrationState::MaxDownloadsReached:
		qDebug() << ("Access failed: max downloads reached");
		this->registrationFailed();
		break;

	case bb::platform::bbm::RegistrationState::MaxAppsReached:
		qDebug() << ("Access failed: max apps reached");
		this->registrationFailed();
		break;

	case bb::platform::bbm::RegistrationState::Expired:
		qDebug() << ("Access failed: access expired");
		this->registrationFailed();
		break;

	default:
		qDebug() << ("Access failed: other errors");
		this->registrationFailed();
		break;
	}
}

void RegistrationHandler::registrationFailed()
{
	//A generic error message is provided here.
	//You could provide a different error for each failure code to instruct the
	//user on how to continue.
	m_statusText->setText(
			"BBM SP registration failed.  Registration is required connect with BlackBerry Messenger.  Please restart the application to try again.");
	m_continueButton->setVisible(false);
}

void RegistrationHandler::continueToMainAppScreen()
{
	//TODO Display the main screen of the application.

}
