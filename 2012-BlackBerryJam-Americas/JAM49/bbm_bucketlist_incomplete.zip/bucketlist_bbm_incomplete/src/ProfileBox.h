/* Copyright (c) 2012 Research In Motion Limited.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#ifndef PROFILEBOX_HPP_
#define PROFILEBOX_HPP_

#include <bb/platform/bbm/ProfileBox>

#include <QtCore/QObject>
#include <QtCore/QString>
#include <QtCore/QMetaType>
#include <QtCore/QVariant>

class ProfileBox : public QObject
{
  Q_OBJECT


public slots:
	//TODO move the createItem line below here to define it as a slot.


public:
  ProfileBox();

  //Registers all of the icons.
  void registerIcons();

  //Creates a new ProfileBox item.
  //TODO Change this to a slot.
  void createItem(const QString& text, const QString& iconPath);

private:
  // Registers the icon at \a path as \a iconId.
  void registerIcon(const QString& path, const int iconId);

  bb::platform::bbm::ProfileBox* m_profileBox;
};

Q_DECLARE_METATYPE(ProfileBox *);

#endif /* PROFILEBOX_HPP_ */
